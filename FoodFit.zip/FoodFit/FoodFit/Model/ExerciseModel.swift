//
//  ExerciseModel.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 11/04/23.
//

import Foundation

struct ExerciseModelElement: Codable {

    var name: String?
    var type: String?
    var muscle: String?
    var equipment: String?
    var difficulty: String?
    var instructions: String?

    init(name: String? = nil, type: String? = nil, muscle: String? = nil, equipment: String? = nil, difficulty: String? = nil, instructions: String? = nil) {
        self.name = name
        self.type = type
        self.muscle = muscle
        self.equipment = equipment
        self.difficulty = difficulty
        self.instructions = instructions
    }

    enum CodingKeys: String, CodingKey {
        case name
        case type
        case muscle
        case equipment
        case difficulty
        case instructions
    }

    static var `exerciseDefault` = ExerciseModelElement(name: "", type: "",
                                                        muscle: "", equipment: "",
                                                        difficulty: "", instructions: ""
    )
}

typealias ExerciseModel = [ExerciseModelElement]
