//
//  NutritionModel.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 04/04/23.
//

import Foundation

struct NutritionModelElement: Codable {
    let name: String?
    let calories: Double?
    let servingSizeG: Double?
    let fatTotalG: Double?
    let fatSaturatedG: Double?
    let proteinG: Double?
    let sodiumMg: Double?
    let potassiumMg: Double?
    let cholesterolMg: Double?
    let carbohydratesTotalG: Double?
    let fiberG: Double?
    let sugarG: Double?

    init(name: String? = nil, calories: Double? = nil, servingSizeG: Double? = nil, fatTotalG: Double? = nil,
         fatSaturatedG: Double? = nil, proteinG: Double? = nil, sodiumMg: Double? = nil, potassiumMg: Double? = nil,
         cholesterolMg: Double? = nil, carbohydratesTotalG: Double? = nil, fiberG: Double? = nil, sugarG: Double? = nil) {
        self.name = name
        self.calories = calories
        self.servingSizeG = servingSizeG
        self.fatTotalG = fatTotalG
        self.fatSaturatedG = fatSaturatedG
        self.proteinG = proteinG
        self.sodiumMg = sodiumMg
        self.potassiumMg = potassiumMg
        self.cholesterolMg = cholesterolMg
        self.carbohydratesTotalG = carbohydratesTotalG
        self.fiberG = fiberG
        self.sugarG = sugarG
    }

    enum CodingKeys: String, CodingKey {
        case name, calories
        case servingSizeG = "serving_size_g"
        case fatTotalG = "fat_total_g"
        case fatSaturatedG = "fat_saturated_g"
        case proteinG = "protein_g"
        case sodiumMg = "sodium_mg"
        case potassiumMg = "potassium_mg"
        case cholesterolMg = "cholesterol_mg"
        case carbohydratesTotalG = "carbohydrates_total_g"
        case fiberG = "fiber_g"
        case sugarG = "sugar_g"
    }
}

typealias NutritionModel = [NutritionModelElement]
