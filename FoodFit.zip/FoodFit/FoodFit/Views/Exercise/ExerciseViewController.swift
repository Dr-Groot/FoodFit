//
//  ExerciseViewController.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 04/04/23.
//

import UIKit
import Lottie
import RxCocoa
import RxSwift

class ExerciseViewController: UIViewController {

    @IBOutlet var exerciseLottieAnimation: LottieAnimationView!
    @IBOutlet var typeButton: UIButton!
    @IBOutlet var muscleButton: UIButton!
    @IBOutlet var difficultyButton: UIButton!
    @IBOutlet var getExerciseButton: UIButton!

    private let viewModel = ExerciseViewModel()
    private let disposeBag = DisposeBag()
    var type = ""
    var muscle = ""
    var difficult = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        configureTheme()
        configDependencies()
        configureAnimation()
        configureTapDifficultyButtonMenu()
        configureTapTypeButtonMenu()
        configureTapMuscleButtonMenu()
    }

    private func configureTheme() {
        navigationItem.title = "Exercise"

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "arrow.triangle.2.circlepath")?.withTintColor(.systemPink, renderingMode: .alwaysOriginal),
            style: .plain,
            target: self,
            action: #selector(resetOptions)
        )
    }

    private func configDependencies() {
        viewModel.exerciseApiStatus.asObservable()
            .bind(onNext: { status in
                switch status {
                case .idle:
                    print("Exercise Api Idle")
                case .progress:
                    self.showLoader()
                    print("Exercise Api Progress")
                case .success:
                    self.hideLoader()
                    print("Exercise Api Success")
                    let exerciseListVC = self.storyboard?.instantiateViewController(withIdentifier: "exerciseListViewController") as! ExerciseListViewController
                    exerciseListVC.exerciseData = self.viewModel.exerciseData.value
                    exerciseListVC.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(exerciseListVC, animated: true)
                case .error:
                    self.hideLoader()
                    print("Exercise Api Error")
                }
            }).disposed(by: disposeBag)
    }

    private func configureAnimation(){
        exerciseLottieAnimation.backgroundColor = .white
        exerciseLottieAnimation.contentMode = .scaleAspectFit
        exerciseLottieAnimation.loopMode = .loop
        exerciseLottieAnimation.animationSpeed = 0.5
        exerciseLottieAnimation.play()
    }

    @IBAction func didTapGetExerciseButton(_ sender: UIButton) {
        viewModel.callExerciseApi(type: self.type, muscle: self.muscle, difficulty: self.difficult)
    }

    @objc func resetOptions() {
        type = ""
        typeButton.setTitle("Select Option", for: .normal)
        muscle = ""
        muscleButton.setTitle("Select Option", for: .normal)
        difficult = ""
        difficultyButton.setTitle("Select Option", for: .normal)
    }

}

// Options
extension ExerciseViewController {

    func configureTapTypeButtonMenu() {
        let option1 = UIAction(title: "Cardio") { (action) in
            self.type = "Cardio"
            self.typeButton.setTitle(self.type, for: .normal)
        }
        let option2 = UIAction(title: "Olympic Weightlifting") { (action) in
            self.type = "Olympic_Weightlifting"
            self.typeButton.setTitle(self.type, for: .normal)
        }
        let option3 = UIAction(title: "Polometrics") { (action) in
            self.type = "Polometrics"
            self.typeButton.setTitle(self.type, for: .normal)
        }
        let option4 = UIAction(title: "Strength") { (action) in
            self.type = "Strength"
            self.typeButton.setTitle(self.type, for: .normal)
        }
        let option5 = UIAction(title: "Stretching") { (action) in
            self.type = "Stretching"
            self.typeButton.setTitle(self.type, for: .normal)
        }
        let option6 = UIAction(title: "Strongman") { (action) in
            self.type = "Strongman"
            self.typeButton.setTitle(self.type, for: .normal)
        }
        let menu = UIMenu(title: "Exercise Type Options", children: [option1, option2, option3, option4, option5, option6])
        typeButton.menu = menu
        typeButton.showsMenuAsPrimaryAction = true
    }

    func configureTapMuscleButtonMenu() {
        let option1 = UIAction(title: "Abdominals") { (action) in
            self.muscle = "Abdominals"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option2 = UIAction(title: "Abductors") { (action) in
            self.muscle = "Abductors"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option3 = UIAction(title: "Adductors") { (action) in
            self.muscle = "Adductors"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option4 = UIAction(title: "Biceps") { (action) in
            self.muscle = "Biceps"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option5 = UIAction(title: "Calves") { (action) in
            self.muscle = "Calves"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option6 = UIAction(title: "Chest") { (action) in
            self.muscle = "Chest"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option7 = UIAction(title: "Forearms") { (action) in
            self.muscle = "Forearms"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option8 = UIAction(title: "Glutes") { (action) in
            self.muscle = "Glutes"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option9 = UIAction(title: "Hamstring") { (action) in
            self.muscle = "Hamstring"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option10 = UIAction(title: "Lats") { (action) in
            self.muscle = "Lats"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option11 = UIAction(title: "Lower Back") { (action) in
            self.muscle = "Lower_Back"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option12 = UIAction(title: "Middle Back") { (action) in
            self.muscle = "Middle_Back"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option13 = UIAction(title: "Neck") { (action) in
            self.muscle = "Neck"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option14 = UIAction(title: "Quardriceps") { (action) in
            self.muscle = "Quardriceps"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option15 = UIAction(title: "Traps") { (action) in
            self.muscle = "Traps"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let option16 = UIAction(title: "Triceps") { (action) in
            self.muscle = "Triceps"
            self.muscleButton.setTitle(self.muscle, for: .normal)
        }
        let menu = UIMenu(title: "Muscle Type Options", children: [option1, option2, option3, option4,
                                                                   option5, option6, option7, option8,
                                                                   option9, option10, option11, option12,
                                                                   option13, option14, option15, option16]
        )
        muscleButton.menu = menu
        muscleButton.showsMenuAsPrimaryAction = true
    }

    func configureTapDifficultyButtonMenu() {
        let option1 = UIAction(title: "Beginner") { (action) in
            self.difficult = "Beginner"
            self.difficultyButton.setTitle(self.difficult, for: .normal)
        }
        let option2 = UIAction(title: "Intermediate") { (action) in
            self.difficult = "Intermediate"
            self.difficultyButton.setTitle(self.difficult, for: .normal)
        }
        let option3 = UIAction(title: "Expert") { (action) in
            self.difficult = "Expert"
            self.difficultyButton.setTitle(self.difficult, for: .normal)
        }
        let menu = UIMenu(title: "Difficulty Options", children: [option1, option2, option3])
        difficultyButton.menu = menu
        difficultyButton.showsMenuAsPrimaryAction = true
    }
}
