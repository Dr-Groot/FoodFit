//
//  ExerciseListViewController.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 11/04/23.
//

import UIKit

class ExerciseListViewController: UIViewController {

    @IBOutlet var exerciseListTableView: UITableView!
    @IBOutlet var noDataLabel: UILabel!

    var exerciseData: ExerciseModel?

    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        configDependencies()
    }

    private func configTheme() {
        noDataLabel.isHidden = true

        if self.exerciseData?.count == 0 {
            noDataLabel.isHidden = false
        }
    }

    private func configDependencies() {
        exerciseListTableView.register(cellType: ExerciseListCellView.self)

        exerciseListTableView.dataSource = self
        exerciseListTableView.delegate = self
    }
}

extension ExerciseListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return exerciseData?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let exerciseCell = tableView.dequeueReusableCell(for: indexPath, cellType: ExerciseListCellView.self)
        exerciseCell.setExerciseToCell(data: (exerciseData?[indexPath.row])!)
        exerciseCell.selectionStyle = .none
        return exerciseCell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let exerciseDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "exerciseDetailController") as! ExerciseDetailViewController
        exerciseDetailVC.exerciseData = exerciseData?[indexPath.row] ?? .exerciseDefault
        exerciseDetailVC.modalPresentationStyle = .popover
        self.present(exerciseDetailVC, animated: true)
    }

}
