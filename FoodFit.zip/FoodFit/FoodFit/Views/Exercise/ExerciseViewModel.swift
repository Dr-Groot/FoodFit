//
//  ExerciseViewModel.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 10/04/23.
//

import Foundation
import Moya
import RxCocoa
import RxSwift

class ExerciseViewModel {

    let exerciseServices = MoyaProvider<ExerciseService>()
    var exerciseApiStatus: BehaviorRelay<ApiRequestStatus> = BehaviorRelay<ApiRequestStatus>(value: .idle)
    let exerciseData: BehaviorRelay<ExerciseModel?> = BehaviorRelay<ExerciseModel?>(value: nil)
    private let disposeBag = DisposeBag()

    func callExerciseApi(type: String, muscle: String, difficulty: String) {
        exerciseApiStatus.accept(.progress)
        exerciseServices.rx
            .request(.exercise(type: type, muscle: muscle, difficulty: difficulty))
            .filterSuccessfulStatusCodes()
            .subscribe({ event in
                switch event {
                case let .success(response):
                    do {
                        let data = try JSONDecoder().decode(ExerciseModel.self, from: response.data)
                        self.exerciseData.accept(data)
                    } catch {
                        print("Enable to Decode data from the Exercise response")
                    }
                    self.exerciseApiStatus.accept(.success)
                case .failure:
                    self.exerciseApiStatus.accept(.success)
                    print("Error while loading Exercise API")
                }
            }).disposed(by: disposeBag)
    }
}
