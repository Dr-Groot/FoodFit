//
//  ExerciseDetailViewController.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 14/04/23.
//

import UIKit

class ExerciseDetailViewController: UIViewController {

    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var typeLabel: UILabel!
    @IBOutlet var muscleLabel: UILabel!
    @IBOutlet var equipmentLabel: UILabel!
    @IBOutlet var difficultyLabel: UILabel!
    @IBOutlet var instructionTextView: UITextView!

    var exerciseData: ExerciseModelElement?

    override func viewDidLoad() {
        super.viewDidLoad()

        setDateToLabels()
    }

    func setDateToLabels() {
        self.nameLabel.text = exerciseData?.name ?? ""
        self.typeLabel.text = exerciseData?.type ?? ""
        self.muscleLabel.text = exerciseData?.muscle ?? ""
        self.equipmentLabel.text = exerciseData?.equipment ?? ""
        self.difficultyLabel.text =  exerciseData?.difficulty ?? ""
        self.instructionTextView.text = exerciseData?.instructions ?? ""
    }
}
