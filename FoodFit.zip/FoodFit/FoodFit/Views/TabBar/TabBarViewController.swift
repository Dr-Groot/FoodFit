//
//  TabBarViewController.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 04/04/23.
//

import UIKit

class TabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
