//
//  SideMenuViewController.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 11/04/23.
//

import UIKit

class SideMenuViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
