//
//  PremiumViewController.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 11/04/23.
//

import UIKit
import Razorpay
import Lottie

class PremiumViewController: UIViewController {

    @IBOutlet var premiumLottieAnimation: LottieAnimationView!
    @IBOutlet var monthlySubscriptionButton: UIButton!
    @IBOutlet var yearlySubscriptionButton: UIButton!

    var razorpay: RazorpayCheckout!

    override func viewDidLoad() {
        super.viewDidLoad()

        configureAnimation()
        congfigureRazorpay()
    }

    private func configureAnimation() {
        premiumLottieAnimation.contentMode = .scaleAspectFit
        premiumLottieAnimation.loopMode = .loop
        premiumLottieAnimation.animationSpeed = 0.5
        premiumLottieAnimation.play()
        premiumLottieAnimation.backgroundColor = .systemIndigo
    }

    private func congfigureRazorpay() {
        razorpay = RazorpayCheckout.initWithKey(Constants.razorPayKey, andDelegate: self)
    }

    internal func showPaymentForm(amount: String, productDescription: String, productName: String, contactNumber: String, email: String){
        let options: [String:Any] = [
                    "amount": amount,
                    "currency": "INR",
                    "description": productDescription,
                    "image": "https://url-to-image.jpg",
                    "name": productName,
                    "prefill": [
                        "contact": contactNumber,
                        "email": email
                    ],
                    "theme": [
                        "color": "#F37254"
                    ]
                ]
        razorpay.open(options)
    }

    @IBAction func didTapMonthlySubscription(_ sender: UIButton) {
        showPaymentForm(amount: "100", productDescription: "FoodFit Monthly Subscription ", productName: "Monthly Subscription", contactNumber: "91-123456789", email: "help@foodfit.com")
    }

    @IBAction func didTapYearlySubscription(_ sender: UIButton) {
        showPaymentForm(amount: "1000", productDescription: "FoodFit Yearly Subscription ", productName: "Yearly Subscription", contactNumber: "91-123456789", email: "help@foodfit.com")
    }

}

extension PremiumViewController: RazorpayPaymentCompletionProtocol {
    func onPaymentError(_ code: Int32, description str: String) {
        print("error: ", code, str)
        let alertController = UIAlertController(title: "FAILURE", message: str, preferredStyle: UIAlertController.Style.alert)
        let cancelAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel, handler: nil)
        alertController.addAction(cancelAction)
        self.view.window?.rootViewController?.present(alertController, animated: true, completion: nil)
    }

    func onPaymentSuccess(_ payment_id: String) {
        print("success: ", payment_id)
        let alertController = UIAlertController(title: "SUCCESS", message: "Payment Id \(payment_id)", preferredStyle: UIAlertController.Style.alert)
        let cancelAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel, handler: nil)
        alertController.addAction(cancelAction)
        self.view.window?.rootViewController?.present(alertController, animated: true, completion: nil)
    }
}
