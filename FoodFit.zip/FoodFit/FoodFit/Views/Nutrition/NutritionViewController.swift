//
//  NutritionViewController.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 04/04/23.
//

import UIKit
import RxSwift
import RxCocoa

class NutritionViewController: UIViewController {
    
    @IBOutlet var searchTextField: UITextField!
    @IBOutlet var searchButton: UIButton!
    @IBOutlet var nutritonTableView: UITableView!

    private let viewModel = NutritionViewModel()
    private let disposeBag = DisposeBag()

    override func viewDidLoad() {
        super.viewDidLoad()

        configTheme()
        configDependencies()
        addBindsToViewModel()
        keyboardHandler()
    }

    private func configTheme() {
        searchButton.layer.cornerRadius = searchButton.frame.height / 2
        searchTextField.placeholder = Constants.nutritionSearchPlacholderText
        navigationItem.title = Constants.nutritionNavigationBarTitle
    }

    private func configDependencies() {

        nutritonTableView.register(cellType: NutritionLottieCellView.self)

        nutritonTableView.register(cellType: NutritionStatsCellView.self)

        nutritonTableView.delegate = self
        nutritonTableView.dataSource = self
    }

    private func addBindsToViewModel() {
        viewModel.nutritionApiRequest
            .asObservable()
            .bind(onNext: { status in
                switch status {
                case .idle:
                    print("Api Request status Idle state")
                case .progress:
                    self.showLoader()
                    print("Api Request status Progress state")
                case .success:
                    self.hideLoader()
                    print("Api Request status Success state")
                case .error:
                    self.hideLoader()
                    print("Api Request status Error state")
                }
            }).disposed(by: disposeBag)

        viewModel.nutritionData
            .asObservable()
            .bind(onNext: { (_) in
                self.nutritonTableView.reloadData()
                print("Got Nutrition Bind Called")
            }).disposed(by: disposeBag)
    }

    @IBAction func didTapSearchButton(_ sender: UIButton) {
        if searchTextField.text == "" {
            let alert = UIAlertController(title: "", message: Constants.nutritionEmptySearchMessage, preferredStyle: .alert)
            self.present(alert, animated: true)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: {
                alert.dismiss(animated: true, completion: nil)
            })
        } else {
            viewModel.callNutritionApi(query: searchTextField.text ?? "")
        }
    }

}

extension NutritionViewController: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if viewModel.nutritionData.value == nil {
            let nutritionLottiecell = tableView.dequeueReusableCell(for: indexPath, cellType: NutritionLottieCellView.self)
            nutritionLottiecell.selectionStyle = .none
            return nutritionLottiecell
        } else {
            let nutritionStatsCell = tableView.dequeueReusableCell(for: indexPath, cellType: NutritionStatsCellView.self)
            nutritionStatsCell.setNutritionStatsValue(data: viewModel.nutritionData.value ?? [])
            nutritionStatsCell.cancelButtonTap = {
                self.viewModel.nutritionData.accept(nil)
                self.searchTextField.text = ""
            }
            nutritionStatsCell.selectionStyle = .none
            return nutritionStatsCell
        }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension NutritionViewController {

    private func keyboardHandler() {
        let tap = UITapGestureRecognizer(
            target: self,
            action: #selector(UIInputViewController.dismissKeyboard)
        )
        view.addGestureRecognizer(tap)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillShow),
            name: UIResponder.keyboardWillShowNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillHide),
            name: UIResponder.keyboardWillHideNotification,
            object: nil
        )
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    @objc func keyboardWillShow(notification: NSNotification) {
        if ((notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey]
             as? NSValue)?.cgRectValue) != nil {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= 0
            }
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
}
