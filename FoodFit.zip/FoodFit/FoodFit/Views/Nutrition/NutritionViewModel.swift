//
//  NutritionViewModel.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 04/04/23.
//

import Foundation
import RxSwift
import RxCocoa
import Moya

class NutritionViewModel {

    let nutritionService = MoyaProvider<NutritionSerice>()
    var nutritionApiRequest: BehaviorRelay<ApiRequestStatus> = BehaviorRelay<ApiRequestStatus>(value: .idle)
    let nutritionData: BehaviorRelay<NutritionModel?> = BehaviorRelay<NutritionModel?>(value: nil)
    private let disposeBag = DisposeBag()

    func callNutritionApi(query: String) {
        nutritionApiRequest.accept(.progress)

        nutritionService.rx
            .request(.nutritionSearch(searchValue: query))
            .filterSuccessfulStatusCodes()
            .subscribe({ event in
                switch event {
                case let.success(response):
                    do{
                        let data = try JSONDecoder().decode(NutritionModel.self, from: response.data)
                        self.nutritionData.accept(data)
                        print(data)
                    } catch {
                        print("Getting error while decoding Nutrition Data")
                    }
                    self.nutritionApiRequest.accept(.success)
                case .failure:
                    self.nutritionApiRequest.accept(.error)
                }
            }).disposed(by: disposeBag)
    }
}
