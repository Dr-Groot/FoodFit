//
//  ApiStatus.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 04/04/23.
//

import Foundation

enum ApiRequestStatus: Equatable {
    case idle
    case progress
    case success
    case error
}
