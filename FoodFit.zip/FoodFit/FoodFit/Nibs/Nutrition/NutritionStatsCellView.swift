//
//  NutritionStatsCellView.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 10/04/23.
//

import UIKit
import Reusable

class NutritionStatsCellView: UITableViewCell, NibReusable {

    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var nameValueLabel: UILabel!
    @IBOutlet var caloriesLabel: UILabel!
    @IBOutlet var caloriesValueLabel: UILabel!
    @IBOutlet var servingSize: UILabel!
    @IBOutlet var servingSizeValueLabel: UILabel!
    @IBOutlet var fatTotalLabel: UILabel!
    @IBOutlet var fatTotalValueLabel: UILabel!
    @IBOutlet var fatSaturatedLabel: UILabel!
    @IBOutlet var fatSaturatedValueLabel: UILabel!
    @IBOutlet var sodiumLabel: UILabel!
    @IBOutlet var sodiumValueLabel: UILabel!
    @IBOutlet var protienLabel: UILabel!
    @IBOutlet var protienValueLabel: UILabel!
    @IBOutlet var potassiumLabel: UILabel!
    @IBOutlet var potassiumValueLabel: UILabel!
    @IBOutlet var cholestrolLabel: UILabel!
    @IBOutlet var cholestrolValueLabel: UILabel!
    @IBOutlet var carbohydrateLabel: UILabel!
    @IBOutlet var carbohydrateValueLabel: UILabel!
    @IBOutlet var fiberLabel: UILabel!
    @IBOutlet var fiberValueLabel: UILabel!
    @IBOutlet var sugarLabel: UILabel!
    @IBOutlet var sugarValueLabel: UILabel!

    var cancelButtonTap : (()-> Void)?

    override func awakeFromNib() {
        super.awakeFromNib()

        configTheme()
    }

    private func configTheme() {
        nameLabel.text = "Name"
        caloriesLabel.text = "Calories"
        servingSize.text = "Serving Size"
        fatTotalLabel.text = "Total Fat"
        fatSaturatedLabel.text = "Saturated Weight"
        protienLabel.text = "Protien"
        sodiumLabel.text = "Sodium"
        potassiumLabel.text = "Potassium"
        cholestrolLabel.text = "Cholesterol"
        carbohydrateLabel.text = "Total Carbohydrate"
        fiberLabel.text = "Fiber"
        sugarLabel.text = "Sugar"
    }

    func setNutritionStatsValue(data: NutritionModel) {
        nameValueLabel.text = data[0].name
        caloriesValueLabel.text = "\(data[0].calories ?? 0)g"
        servingSizeValueLabel.text = "\(data[0].servingSizeG ?? 0)g"
        fatTotalValueLabel.text = "\(data[0].fatTotalG ?? 0)g"
        fatSaturatedValueLabel.text = "\(data[0].fatSaturatedG ?? 0)g"
        protienValueLabel.text = "\(data[0].proteinG ?? 0)g"
        sodiumValueLabel.text = "\(data[0].sodiumMg ?? 0)mg"
        potassiumValueLabel.text = "\(data[0].potassiumMg ?? 0)mg"
        cholestrolValueLabel.text = "\(data[0].cholesterolMg ?? 0)mg"
        carbohydrateValueLabel.text = "\(data[0].carbohydratesTotalG ?? 0)g"
        fiberValueLabel.text = "\(data[0].fiberG ?? 0)g"
        sugarValueLabel.text = "\(data[0].sugarG ?? 0)g"
    }

    @IBAction func didTapClearButton(_ sender: UIButton) {
        cancelButtonTap?()
    }
}
