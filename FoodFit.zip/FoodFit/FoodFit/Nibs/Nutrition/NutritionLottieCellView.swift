//
//  NutritionLottieCellView.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 10/04/23.
//

import UIKit
import Reusable
import Lottie

class NutritionLottieCellView: UITableViewCell, NibReusable {

    @IBOutlet var animationView: LottieAnimationView!

    override func awakeFromNib() {
        super.awakeFromNib()

        configTheme()
        configDependencies()
        setupAnimation()
    }

    private func configTheme() {}

    private func configDependencies() {}

    private func setupAnimation() {
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .loop
        animationView.animationSpeed = 0.5
        animationView.play()
    }

}
