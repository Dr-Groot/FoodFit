//
//  ExerciseListCellView.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 11/04/23.
//

import UIKit
import Reusable

class ExerciseListCellView: UITableViewCell, NibReusable {

    @IBOutlet var outerView: UIView!
    @IBOutlet var innerView: UIView!
    @IBOutlet var difficultyLabel: UILabel!
    @IBOutlet var muscleLabel: UILabel!
    @IBOutlet var typeLabel: UILabel!
    @IBOutlet var equipmentLabel: UILabel!
    @IBOutlet var isntructionLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()

        configTheme()
        configDependencies()
    }

    private func configTheme() {
        innerView.layer.cornerRadius = 10
        outerView.layer.cornerRadius = 10
    }

    private func configDependencies() {}

    func setExerciseToCell(data: ExerciseModelElement) {
        if data.difficulty == "beginner" {
            outerView.backgroundColor = .systemGreen
            difficultyLabel.text = "Beginner"
        } else if data.difficulty == "intermediate" {
            outerView.backgroundColor = .systemYellow
            difficultyLabel.text = "Intermediate"
        } else {
            outerView.backgroundColor = .systemRed
            difficultyLabel.text = "Difficult"
        }
        muscleLabel.text = data.muscle
        typeLabel.text = data.type
        equipmentLabel.text = data.equipment
        isntructionLabel.text = data.instructions
    }

}
