//
//  ExerciseService.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 10/04/23.
//

import Foundation
import Moya

enum ExerciseService {
    case exercise(type: String, muscle: String, difficulty: String)
}

extension ExerciseService: TargetType {
    var baseURL: URL {
        switch self {
        case .exercise:
            return URL(string: Constants.baseUrl)!
        }
    }

    var path: String {
        switch self {
        case .exercise:
            return "exercises"
        }
    }

    var method: Moya.Method {
        switch self {
        case .exercise:
            return .get
        }
    }

    var sampleData: Data {
        let json = ""
        return json.data(using: String.Encoding.utf8)!
    }

    var task: Moya.Task {
        switch self {
        case let .exercise(type, muscle, difficulty):
            return .requestParameters(
                parameters: [
                    "type": type,
                    "muscle": muscle,
                    "difficulty": difficulty
                ],
                encoding: URLEncoding.queryString
            )
        }
    }

    var headers: [String : String]? {
        switch self {
        case .exercise:
            return ["X-Api-Key": Constants.apiKeyApiNinja]
        }
    }

}
