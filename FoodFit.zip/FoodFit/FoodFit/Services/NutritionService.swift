//
//  NutritionService.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 04/04/23.
//

import Foundation
import UIKit
import Moya

enum NutritionSerice {
    case nutritionSearch(searchValue: String)
}

extension NutritionSerice: TargetType {
    var baseURL: URL {
        switch self {
        case .nutritionSearch:
            return URL(string: Constants.baseUrl)!
        }
    }

    var path: String {
        switch self {
        case .nutritionSearch:
            return "nutrition"
        }
    }

    var method: Moya.Method {
        switch self {
        case .nutritionSearch:
            return .get
        }
    }

    var sampleData: Data {
        let json = ""
        return json.data(using: String.Encoding.utf8)!
    }

    var task: Moya.Task {
        switch self {
        case let .nutritionSearch(searchValue):
            return .requestParameters(
                parameters: [
                    "query": searchValue
                ],
                encoding: URLEncoding.queryString
            )
        }
    }

    var headers: [String : String]? {
        switch self {
        case .nutritionSearch:
            return ["X-Api-Key": Constants.apiKeyApiNinja]
        }
    }
}
