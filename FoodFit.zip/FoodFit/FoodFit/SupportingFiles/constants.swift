//
//  constants.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 04/04/23.
//

import Foundation

struct Constants {
    static var baseUrl = "https://api.api-ninjas.com/v1/"
    static var nutritionSearchPlacholderText = "Search Food..."
    static var nutritionNavigationBarTitle = "Nutrition"
    static var nutritionEmptySearchMessage = "There is no EMPTY food"
    static var apiKeyApiNinja = ""
    static var razorPayKey = ""
}
