//
//  UIViewController+Extension.swift
//  FoodFit
//
//  Created by Amam Pratap Singh on 10/04/23.
//

import Foundation
import NVActivityIndicatorView

extension UIViewController {
    func showLoader(indicatorColor: UIColor = .systemMint) {
        let activityData = ActivityData(type: .circleStrokeSpin, color: indicatorColor)
        NVActivityIndicatorPresenter.sharedInstance.startAnimating(activityData, nil)
    }

    func hideLoader() {
        NVActivityIndicatorPresenter.sharedInstance.stopAnimating(nil)
    }
}
